# QuizSeratus - Aplikasi Quiz Android

Aplikasi quiz Android yang dibuat untuk tugas praktikum dengan fitur login, register, dan quiz interaktif.

## Fitur Aplikasi

### 🔐 Sistem Autentikasi
- **Login**: Masuk dengan username dan password
- **Register**: Daftar akun baru
- **Session Management**: Username tersimpan selama sesi aplikasi

### 📚 Kategori Quiz
Aplikasi menyediakan 3 kategori quiz dengan masing-masing 15 soal:

1. **Pemrograman Mobile** - Soal tentang Android Studio, Kotlin, Java, dan development mobile
2. **Business Intelligence** - Soal tentang BI, data warehouse, ETL, dan analytics
3. **Audit Sistem Informasi** - Soal tentang audit SI, kontrol internal, dan compliance

### 🎯 Fitur Quiz
- **15 Soal per Kategori**: Setiap kategori berisi 15 pertanyaan pilihan ganda
- **Navigasi Soal**: Progress indicator dan navigasi antar soal
- **Scoring System**: Sistem penilaian otomatis
- **Hasil Instan**: Tampilan skor dan pesan motivasi setelah selesai quiz

### 👤 Profil Pengguna
- **Riwayat Skor**: Menampilkan semua skor yang pernah dicapai
- **Statistik**: Total quiz yang diselesaikan
- **Persistent Storage**: Skor tersimpan di database lokal

## Struktur Database

### Tabel `users`
- `id` (INTEGER PRIMARY KEY)
- `username` (TEXT UNIQUE)
- `password` (TEXT)

### Tabel `scores`
- `id` (INTEGER PRIMARY KEY)
- `user` (TEXT)
- `category` (TEXT)
- `score` (INTEGER)

### Tabel `questions`
- `id` (INTEGER PRIMARY KEY)
- `category` (TEXT)
- `question` (TEXT)
- `option_a` (TEXT)
- `option_b` (TEXT)
- `option_c` (TEXT)
- `option_d` (TEXT)
- `answer` (TEXT)

## Cara Menggunakan

1. **Register/Login**: Daftar akun baru atau login dengan akun yang sudah ada
2. **Pilih Kategori**: Pilih salah satu dari 3 kategori quiz yang tersedia
3. **Mulai Quiz**: Jawab 15 pertanyaan pilihan ganda
4. **Lihat Hasil**: Skor akan ditampilkan dengan pesan motivasi
5. **Cek Profil**: Lihat riwayat skor di halaman profil

## Teknologi yang Digunakan

- **Android Studio**: IDE utama
- **Java**: Bahasa pemrograman
- **SQLite**: Database lokal
- **Fragment**: UI Navigation
- **Material Design**: UI Components

## Screenshot Aplikasi

Aplikasi memiliki 6 halaman utama:
1. Login Screen
2. Register Screen  
3. Home Screen (Pilih Kategori)
4. Quiz Screen (15 Soal)
5. Result Screen (Hasil Skor)
6. Profile Screen (Riwayat Skor)

## Instalasi

1. Clone repository ini
2. Buka dengan Android Studio
3. Sync project dengan Gradle
4. Run aplikasi di emulator atau device Android

## Requirements

- Android Studio 4.0+
- Android SDK 21+ (Android 5.0)
- Java 11+

---

**Dibuat untuk tugas praktikum Android Development** 📱✨



