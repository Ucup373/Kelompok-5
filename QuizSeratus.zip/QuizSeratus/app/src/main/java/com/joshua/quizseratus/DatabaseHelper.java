package com.joshua.quizseratus.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "quizseratus.db";
    private static final int DATABASE_VERSION = 7;

    // Nama tabel dan kolom
    private static final String TABLE_USERS = "users";
    private static final String COL_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_AVATAR = "avatar";
    private static final String COL_DESCRIPTION = "description";

    private static final String TABLE_SCORES = "scores";
    private static final String COL_USER = "user";
    private static final String COL_CATEGORY = "category";
    private static final String COL_SCORE = "score";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // === Tabel users ===
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT, " +
                COL_AVATAR + " TEXT DEFAULT 'avatar_default', " +
                COL_DESCRIPTION + " TEXT DEFAULT 'Belum ada deskripsi')");

        // === Tabel scores ===
        db.execSQL("CREATE TABLE " + TABLE_SCORES + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER + " TEXT, " +
                COL_CATEGORY + " TEXT, " +
                COL_SCORE + " INTEGER)");

        // === Tabel questions ===
        db.execSQL("CREATE TABLE questions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "category TEXT, " +
                "question TEXT, " +
                "option_a TEXT, " +
                "option_b TEXT, " +
                "option_c TEXT, " +
                "option_d TEXT, " +
                "answer TEXT)");

        // Isi soal default
        insertDefaultQuestions(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Tambahkan kolom avatar dan description ke tabel users
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COL_AVATAR + " TEXT DEFAULT 'avatar_default'");
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COL_DESCRIPTION + " TEXT DEFAULT 'Belum ada deskripsi'");
        }
        if (oldVersion < 3) {
            // Pastikan tabel scores ada
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SCORES + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USER + " TEXT, " +
                    COL_CATEGORY + " TEXT, " +
                    COL_SCORE + " INTEGER)");

            // Hapus dan buat ulang tabel questions dengan soal yang lebih lengkap
            db.execSQL("DROP TABLE IF EXISTS questions");
            db.execSQL("CREATE TABLE questions (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "category TEXT, " +
                    "question TEXT, " +
                    "option_a TEXT, " +
                    "option_b TEXT, " +
                    "option_c TEXT, " +
                    "option_d TEXT, " +
                    "answer TEXT)");
            insertDefaultQuestions(db);
        }
        if (oldVersion < 4) {
            // Pastikan tabel scores ada
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SCORES + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USER + " TEXT, " +
                    COL_CATEGORY + " TEXT, " +
                    COL_SCORE + " INTEGER)");

            // Pastikan database di-upgrade dengan soal yang benar
            db.execSQL("DROP TABLE IF EXISTS questions");
            db.execSQL("CREATE TABLE questions (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "category TEXT, " +
                    "question TEXT, " +
                    "option_a TEXT, " +
                    "option_b TEXT, " +
                    "option_c TEXT, " +
                    "option_d TEXT, " +
                    "answer TEXT)");
            insertDefaultQuestions(db);
        }
        if (oldVersion < 6) {
            // Pastikan tabel scores ada
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SCORES + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USER + " TEXT, " +
                    COL_CATEGORY + " TEXT, " +
                    COL_SCORE + " INTEGER)");

            // Perbaiki jumlah soal Audit Sistem Informasi menjadi 15
            db.execSQL("DROP TABLE IF EXISTS questions");
            db.execSQL("CREATE TABLE questions (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "category TEXT, " +
                    "question TEXT, " +
                    "option_a TEXT, " +
                    "option_b TEXT, " +
                    "option_c TEXT, " +
                    "option_d TEXT, " +
                    "answer TEXT)");
            insertDefaultQuestions(db);
        }
        if (oldVersion < 7) {
            // Pastikan tabel scores ada untuk semua versi lama
            db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SCORES + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USER + " TEXT, " +
                    COL_CATEGORY + " TEXT, " +
                    COL_SCORE + " INTEGER)");
        }
    }

    // ====== USER FUNCTIONS ======

    // Cek apakah username sudah ada
    public boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + " = ?", new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Tambahkan user baru
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Cek login
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?", new String[]{username, password});
        boolean valid = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return valid;
    }

    // Update profil user
    public boolean updateProfile(String username, String avatar, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_AVATAR, avatar);
        values.put(COL_DESCRIPTION, description);
        int result = db.update(TABLE_USERS, values, COL_USERNAME + "=?", new String[]{username});
        db.close();
        return result > 0;
    }

    // Get profil user
    public Cursor getUserProfile(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT " + COL_USERNAME + ", " + COL_AVATAR + ", " + COL_DESCRIPTION +
                " FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + " = ?", new String[]{username});
    }

    // ====== SCORE FUNCTIONS ======

    // Simpan atau update skor
    public void saveScore(String username, String category, int score) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_SCORES + " WHERE " +
                COL_USER + " = ? AND " + COL_CATEGORY + " = ?", new String[]{username, category});

        if (cursor.moveToFirst()) {
            // Update skor jika sudah ada
            ContentValues values = new ContentValues();
            values.put(COL_SCORE, score);
            db.update(TABLE_SCORES, values, COL_USER + "=? AND " + COL_CATEGORY + "=?",
                    new String[]{username, category});
        } else {
            // Insert skor baru
            ContentValues values = new ContentValues();
            values.put(COL_USER, username);
            values.put(COL_CATEGORY, category);
            values.put(COL_SCORE, score);
            db.insert(TABLE_SCORES, null, values);
        }

        cursor.close();
        db.close();
    }

    // Ambil skor user untuk 1 kategori
    public int getUserScore(String username, String category) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COL_SCORE + " FROM " + TABLE_SCORES +
                        " WHERE " + COL_USER + " = ? AND " + COL_CATEGORY + " = ?",
                new String[]{username, category});
        int score = 0;
        if (cursor.moveToFirst()) {
            score = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return score;
    }

    // Ambil semua skor user (untuk ProfileFragment)
    public Cursor getScores(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT " + COL_CATEGORY + " AS matkul, " + COL_SCORE + " AS score " +
                "FROM " + TABLE_SCORES + " WHERE " + COL_USER + " = ?", new String[]{username});
    }

    // ====== QUESTION FUNCTIONS ======

    // Tambah soal default
    private void insertDefaultQuestions(SQLiteDatabase db) {
        Cursor c = db.rawQuery("SELECT * FROM questions", null);
        if (c.getCount() == 0) {
            // Pemrograman Mobile
            db.execSQL("INSERT INTO questions (category, question, option_a, option_b, option_c, option_d, answer) VALUES " +
                    "('Pemrograman Mobile', 'Apa bahasa utama Android Studio?', 'Python', 'Java', 'Kotlin', 'C++', 'Kotlin')," +
                    "('Pemrograman Mobile', 'File layout Android disimpan di folder?', 'res/drawable', 'res/layout', 'res/values', 'res/menu', 'res/layout')," +
                    "('Pemrograman Mobile', 'Activity digunakan untuk?', 'Tampilan utama', 'Database', 'Networking', 'Security', 'Tampilan utama')," +
                    "('Pemrograman Mobile', 'Fragment digunakan untuk?', 'Halaman utama', 'Bagian dari UI', 'File resource', 'Class utilitas', 'Bagian dari UI')," +
                    "('Pemrograman Mobile', 'Manifest berisi?', 'Kode Java', 'Konfigurasi Aplikasi', 'Database', 'Layout', 'Konfigurasi Aplikasi')," +
                    "('Pemrograman Mobile', 'Bahasa bawaan pertama Android?', 'Java', 'Python', 'Ruby', 'C', 'Java')," +
                    "('Pemrograman Mobile', 'File XML digunakan untuk?', 'Desain UI', 'Menjalankan kode', 'Menyimpan data', 'Mengelola event', 'Desain UI')," +
                    "('Pemrograman Mobile', 'Android Studio dikembangkan oleh?', 'Microsoft', 'Google', 'Oracle', 'Facebook', 'Google')," +
                    "('Pemrograman Mobile', 'Fungsi Intent adalah?', 'Pindah activity', 'Simpan data', 'Menampilkan toast', 'Menutup app', 'Pindah activity')," +
                    "('Pemrograman Mobile', 'Tipe layout untuk posisi bebas?', 'LinearLayout', 'RelativeLayout', 'ConstraintLayout', 'FrameLayout', 'ConstraintLayout')," +
                    "('Pemrograman Mobile', 'RecyclerView digunakan untuk?', 'Menampilkan list', 'Menampilkan gambar', 'Input teks', 'Audio', 'Menampilkan list')," +
                    "('Pemrograman Mobile', 'Gradle digunakan untuk?', 'Build dan dependency', 'UI desain', 'Database', 'Debugging', 'Build dan dependency')," +
                    "('Pemrograman Mobile', 'Kotlin bersifat?', 'Statically typed', 'Dynamically typed', 'Functional only', 'Scripting', 'Statically typed')," +
                    "('Pemrograman Mobile', 'MVVM adalah?', 'Pola arsitektur', 'Library', 'API', 'Fungsi Android', 'Pola arsitektur')," +
                    "('Pemrograman Mobile', 'File resource string ada di?', 'res/values/strings.xml', 'res/layout', 'res/drawable', 'res/raw', 'res/values/strings.xml')," +

                    // Business Intelligence
                    "('Business Intelligence', 'BI adalah singkatan dari?', 'Business Information', 'Business Intelligence', 'Basic Internet', 'Binary Interface', 'Business Intelligence')," +
                    "('Business Intelligence', 'Tujuan utama BI?', 'Menyimpan data', 'Menganalisis data', 'Menghapus data', 'Mencetak laporan', 'Menganalisis data')," +
                    "('Business Intelligence', 'ETL dalam BI berarti?', 'Extract Transform Load', 'Extract Transfer Load', 'Edit Transform Load', 'End Transform Logic', 'Extract Transform Load')," +
                    "('Business Intelligence', 'Contoh tools BI?', 'Android Studio', 'Power BI', 'Eclipse', 'Photoshop', 'Power BI')," +
                    "('Business Intelligence', 'Data warehouse adalah?', 'Database sementara', 'Gudang data terpusat', 'File Excel', 'Backup data', 'Gudang data terpusat')," +
                    "('Business Intelligence', 'OLAP dalam BI berarti?', 'Online Analytical Processing', 'Offline Analytical Processing', 'Online Application Processing', 'Offline Application Processing', 'Online Analytical Processing')," +
                    "('Business Intelligence', 'Dashboard BI berfungsi untuk?', 'Menyimpan data', 'Visualisasi data', 'Menghapus data', 'Backup data', 'Visualisasi data')," +
                    "('Business Intelligence', 'Data mining adalah?', 'Menambang data', 'Menganalisis pola data', 'Menghapus data', 'Menyimpan data', 'Menganalisis pola data')," +
                    "('Business Intelligence', 'KPI dalam BI berarti?', 'Key Performance Indicator', 'Key Process Indicator', 'Key Product Indicator', 'Key Program Indicator', 'Key Performance Indicator')," +
                    "('Business Intelligence', 'Real-time BI artinya?', 'Analisis data real-time', 'Data lama', 'Data statis', 'Data manual', 'Analisis data real-time')," +
                    "('Business Intelligence', 'Data mart adalah?', 'Database kecil', 'Subset data warehouse', 'File Excel', 'Backup data', 'Subset data warehouse')," +
                    "('Business Intelligence', 'ROLAP dalam BI berarti?', 'Relational OLAP', 'Real-time OLAP', 'Remote OLAP', 'Rapid OLAP', 'Relational OLAP')," +
                    "('Business Intelligence', 'Fungsi ETL dalam BI?', 'Extract, Transform, Load data', 'Edit, Test, Launch', 'Execute, Transfer, Load', 'Export, Transform, Load', 'Extract, Transform, Load data')," +
                    "('Business Intelligence', 'Data visualization adalah?', 'Menyimpan data', 'Menggambar data', 'Menyajikan data visual', 'Menghapus data', 'Menyajikan data visual')," +
                    "('Business Intelligence', 'Business Intelligence membantu?', 'Mengambil keputusan bisnis', 'Menyimpan data', 'Menghapus data', 'Backup data', 'Mengambil keputusan bisnis')," +

                    // Audit Sistem Informasi
                    "('Audit Sistem Informasi', 'Tujuan audit SI adalah?', 'Menambah data', 'Mengamankan data', 'Menilai sistem', 'Menghapus data', 'Menilai sistem')," +
                    "('Audit Sistem Informasi', 'Audit dilakukan oleh?', 'Programmer', 'Auditor', 'Manajer proyek', 'User', 'Auditor')," +
                    "('Audit Sistem Informasi', 'Tahap pertama audit SI?', 'Perencanaan audit', 'Eksekusi audit', 'Pelaporan', 'Evaluasi akhir', 'Perencanaan audit')," +
                    "('Audit Sistem Informasi', 'Standar audit SI berasal dari?', 'ISO', 'IEEE', 'GAAP', 'OOP', 'ISO')," +
                    "('Audit Sistem Informasi', 'Laporan audit diserahkan kepada?', 'Auditee', 'Auditor lain', 'Publik', 'Vendor', 'Auditee')," +
                    "('Audit Sistem Informasi', 'Audit internal dilakukan oleh?', 'Auditor eksternal', 'Auditor internal', 'User', 'Developer', 'Auditor internal')," +
                    "('Audit Sistem Informasi', 'Tujuan audit keamanan?', 'Mengamankan sistem', 'Menambah user', 'Menyimpan data', 'Meningkatkan UI', 'Mengamankan sistem')," +
                    "('Audit Sistem Informasi', 'Audit compliance mengecek?', 'Kepatuhan regulasi', 'Kualitas kode', 'Performance sistem', 'User interface', 'Kepatuhan regulasi')," +
                    "('Audit Sistem Informasi', 'Risk assessment dalam audit?', 'Penilaian risiko', 'Penilaian kualitas', 'Penilaian performance', 'Penilaian UI', 'Penilaian risiko')," +
                    "('Audit Sistem Informasi', 'Audit trail adalah?', 'Jejak audit', 'File log', 'Database', 'Hardware', 'Jejak audit')," +
                    "('Audit Sistem Informasi', 'Tujuan audit operasional?', 'Menilai efisiensi operasi', 'Menilai kualitas kode', 'Menilai performance', 'Menilai UI', 'Menilai efisiensi operasi')," +
                    "('Audit Sistem Informasi', 'Audit finansial mengecek?', 'Aspek keuangan', 'Kualitas kode', 'Performance sistem', 'User interface', 'Aspek keuangan')," +
                    "('Audit Sistem Informasi', 'COBIT adalah?', 'Framework tata kelola TI', 'Database', 'Programming language', 'UI framework', 'Framework tata kelola TI')," +
                    "('Audit Sistem Informasi', 'Tujuan akhir audit?', 'Rekomendasi perbaikan', 'Menambah data', 'Hapus file', 'Meningkatkan UI', 'Rekomendasi perbaikan')," +
                    "('Audit Sistem Informasi', 'Audit sistem informasi mencakup?', 'Hardware, software, data', 'Hanya hardware', 'Hanya software', 'Hanya data', 'Hardware, software, data');");
        }
        c.close();
    }

    // Ambil soal berdasarkan kategori
    public Cursor getQuestionsByCategory(String category) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM questions WHERE category=?", new String[]{category});
    }

    // Debug: Hitung jumlah soal per kategori
    public void debugQuestionCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] categories = {"Pemrograman Mobile", "Business Intelligence", "Audit Sistem Informasi"};

        for (String category : categories) {
            Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM questions WHERE category=?", new String[]{category});
            if (cursor.moveToFirst()) {
                int count = cursor.getInt(0);
                android.util.Log.d("DatabaseHelper", "Kategori " + category + ": " + count + " soal");
            }
            cursor.close();
        }
        db.close();
    }
}
