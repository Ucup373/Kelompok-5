package com.joshua.quizseratus;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.joshua.quizseratus.MainActivity;
import com.joshua.quizseratus.R;
import com.joshua.quizseratus.ProfileFragment;
import com.joshua.quizseratus.QuizFragment;

public class HomeFragment extends Fragment {

    private LinearLayout listView;
    private Button btnProfile, btnLogout;
    private String[] mataKuliah = {
            "Pemrograman Mobile",
            "Business Intelligence",
            "Audit Sistem Informasi"
    };
    private String[] mataKuliahIcons = {
            "📱",
            "📊",
            "🔍"
    };
    private int[] backgroundResources = {
            R.drawable.category_icon_background_mobile,
            R.drawable.category_icon_background_bi,
            R.drawable.category_icon_background_audit
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        listView = view.findViewById(R.id.listMataKuliah);
        btnProfile = view.findViewById(R.id.btnProfile);
        btnLogout = view.findViewById(R.id.btnLogout);

        // Tambahkan card untuk setiap kategori
        for (int i = 0; i < mataKuliah.length; i++) {
            View categoryCard = inflater.inflate(R.layout.item_quiz_category, listView, false);

            TextView categoryIcon = categoryCard.findViewById(R.id.categoryIcon);
            TextView categoryName = categoryCard.findViewById(R.id.categoryName);
            TextView categoryDescription = categoryCard.findViewById(R.id.categoryDescription);

            categoryIcon.setText(mataKuliahIcons[i]);
            categoryIcon.setBackgroundResource(backgroundResources[i]);
            categoryName.setText(mataKuliah[i]);
            categoryDescription.setText("15 soal");

            final int position = i;
            categoryCard.setOnClickListener(v -> {
                String selected = mataKuliah[position];
                Toast.makeText(getContext(), "Memulai quiz: " + selected, Toast.LENGTH_SHORT).show();

                // Navigasi ke QuizFragment
                Bundle bundle = new Bundle();
                bundle.putString("category", selected);
                bundle.putString("username", ((MainActivity) getActivity()).getCurrentUser());

                QuizFragment quizFragment = new QuizFragment();
                quizFragment.setArguments(bundle);

                ((MainActivity) getActivity()).navigateTo(quizFragment);
            });

            listView.addView(categoryCard);
        }

        // Tombol Profile
        btnProfile.setOnClickListener(v -> {
            ((MainActivity) getActivity()).navigateTo(new ProfileFragment());
        });

        // Tombol Logout
        btnLogout.setOnClickListener(v -> {
            // Kembali ke halaman login
            ((MainActivity) getActivity()).navigateTo(new com.joshua.quizseratus.LoginFragment());
        });

        return view;
    }
}
