package com.joshua.quizseratus;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginFragment extends Fragment {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvRegister;

    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // Inisialisasi komponen UI
        etUsername = view.findViewById(R.id.etUsername);   // USERNAME, bukan email
        etPassword = view.findViewById(R.id.etPassword);
        btnLogin = view.findViewById(R.id.btnLogin);
        tvRegister = view.findViewById(R.id.tvRegister);

        // Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Tombol Login
        btnLogin.setOnClickListener(v -> loginUser());

        // Tombol Register
        tvRegister.setOnClickListener(v -> {
            ((MainActivity) getActivity()).navigateTo(new RegisterFragment());
        });

        return view;
    }

    private void loginUser() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(getContext(), "Isi semua kolom!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (username.contains(" ")) {
            Toast.makeText(getContext(), "Username tidak boleh ada spasi!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Sama seperti saat register: buat email palsu dari username
        String fakeEmail = username + "@quizseratus.app";

        mAuth.signInWithEmailAndPassword(fakeEmail, password)
                .addOnCompleteListener(requireActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getContext(), "Login berhasil!", Toast.LENGTH_SHORT).show();

                            // Simpan username ke MainActivity untuk dipakai di fragment lain
                            ((MainActivity) getActivity()).setCurrentUser(username);

                            // Navigasi ke halaman utama (Home)
                            ((MainActivity) getActivity()).navigateTo(new HomeFragment());
                        } else {
                            String msg = (task.getException() != null)
                                    ? task.getException().getMessage()
                                    : "Username atau password salah!";
                            Toast.makeText(getContext(), "Login gagal: " + msg, Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
