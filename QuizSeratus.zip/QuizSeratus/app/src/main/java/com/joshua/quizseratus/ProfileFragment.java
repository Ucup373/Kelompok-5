package com.joshua.quizseratus;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.joshua.quizseratus.MainActivity;
import com.joshua.quizseratus.R;
import com.joshua.quizseratus.database.DatabaseHelper;
import com.joshua.quizseratus.HomeFragment;

public class ProfileFragment extends Fragment {

    private String currentUser;
    private TextView txtUsername, txtTotalQuizzes, txtAverageScore, txtDescription;
    private ImageView imgAvatar;
    private LinearLayout layoutScores;
    private Button btnBackToHome, btnEditProfile;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Ambil username dari MainActivity
        currentUser = ((MainActivity) getActivity()).getCurrentUser();

        // Initialize views
        txtUsername = view.findViewById(R.id.txtUsername);
        txtTotalQuizzes = view.findViewById(R.id.txtTotalQuizzes);
        txtAverageScore = view.findViewById(R.id.txtAverageScore);
        txtDescription = view.findViewById(R.id.txtDescription);
        imgAvatar = view.findViewById(R.id.imgAvatar);
        layoutScores = view.findViewById(R.id.layoutScores);
        btnBackToHome = view.findViewById(R.id.btnBackToHome);
        btnEditProfile = view.findViewById(R.id.btnEditProfile);

        dbHelper = new DatabaseHelper(getContext());

        // Load user profile
        loadUserProfile();

        // Load quiz statistics
        loadQuizStatistics();

        // Tombol edit profil
        btnEditProfile.setOnClickListener(v -> showEditProfileDialog());

        // Tombol kembali ke home
        btnBackToHome.setOnClickListener(v -> {
            ((MainActivity) getActivity()).navigateTo(new HomeFragment());
        });

        return view;
    }

    private void loadUserProfile() {
        Cursor cursor = dbHelper.getUserProfile(currentUser);
        if (cursor.moveToFirst()) {
            String username = cursor.getString(cursor.getColumnIndexOrThrow("username"));
            String avatar = cursor.getString(cursor.getColumnIndexOrThrow("avatar"));
            String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

            txtUsername.setText(username);
            txtDescription.setText(description);

            // Set avatar
            int avatarResource = getResources().getIdentifier(avatar, "drawable", getContext().getPackageName());
            if (avatarResource != 0) {
                imgAvatar.setImageResource(avatarResource);
            }
        }
        cursor.close();
    }

    private void loadQuizStatistics() {
        Cursor cursor = dbHelper.getScores(currentUser);
        int totalQuizzes = cursor.getCount();
        txtTotalQuizzes.setText("Total Quiz: " + totalQuizzes);

        // Calculate average score
        int totalScore = 0;
        if (cursor.moveToFirst()) {
            do {
                int score = cursor.getInt(cursor.getColumnIndexOrThrow("score"));
                totalScore += score;
            } while (cursor.moveToNext());
        }

        double averagePercentage = totalQuizzes > 0 ? (double) totalScore / (totalQuizzes * 15) * 100 : 0;
        txtAverageScore.setText("Rata-rata: " + String.format("%.1f", averagePercentage) + "%");

        // Load quiz history
        layoutScores.removeAllViews();
        if (cursor.getCount() == 0) {
            TextView tv = new TextView(getContext());
            tv.setText("Belum ada skor tersimpan.\nSilakan selesaikan quiz terlebih dahulu!");
            tv.setTextSize(16);
            tv.setPadding(0, 20, 0, 20);
            tv.setTextColor(getResources().getColor(android.R.color.darker_gray));
            layoutScores.addView(tv);
        } else {
            cursor.moveToFirst();
            do {
                String category = cursor.getString(cursor.getColumnIndexOrThrow("matkul"));
                int score = cursor.getInt(cursor.getColumnIndexOrThrow("score"));
                double percentage = (double) score / 15 * 100;

                TextView tv = new TextView(getContext());
                tv.setText("📚 " + category + "\nSkor: " + score + "/15 (" + String.format("%.1f", percentage) + "%)");
                tv.setTextSize(16);
                tv.setPadding(16, 12, 16, 12);
                tv.setBackgroundResource(android.R.drawable.edit_text);
                tv.setTextColor(getResources().getColor(android.R.color.black));

                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                params.setMargins(0, 8, 0, 8);
                tv.setLayoutParams(params);

                layoutScores.addView(tv);
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void showEditProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_edit_profile, null);
        builder.setView(dialogView);

        // Get current profile data
        Cursor cursor = dbHelper.getUserProfile(currentUser);
        String currentAvatar = "avatar_default";
        String currentDescription = "Belum ada deskripsi";

        if (cursor.moveToFirst()) {
            currentAvatar = cursor.getString(cursor.getColumnIndexOrThrow("avatar"));
            currentDescription = cursor.getString(cursor.getColumnIndexOrThrow("description"));
        }
        cursor.close();

        // Initialize dialog views
        ImageView avatar1 = dialogView.findViewById(R.id.avatar1);
        ImageView avatar2 = dialogView.findViewById(R.id.avatar2);
        ImageView avatar3 = dialogView.findViewById(R.id.avatar3);
        ImageView avatar4 = dialogView.findViewById(R.id.avatar4);
        EditText etDescription = dialogView.findViewById(R.id.etDescription);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);
        Button btnSave = dialogView.findViewById(R.id.btnSave);

        // Set current values
        etDescription.setText(currentDescription);

        // Set current avatar as selected
        String[] avatars = {"avatar_default", "avatar_1", "avatar_2", "avatar_3"};
        ImageView[] avatarViews = {avatar1, avatar2, avatar3, avatar4};

        for (int i = 0; i < avatars.length; i++) {
            if (avatars[i].equals(currentAvatar)) {
                avatarViews[i].setSelected(true);
                break;
            }
        }

        // Avatar selection
        final String[] selectedAvatar = {currentAvatar};

        avatar1.setOnClickListener(v -> {
            clearAvatarSelection(avatarViews);
            avatar1.setSelected(true);
            selectedAvatar[0] = "avatar_default";
        });

        avatar2.setOnClickListener(v -> {
            clearAvatarSelection(avatarViews);
            avatar2.setSelected(true);
            selectedAvatar[0] = "avatar_1";
        });

        avatar3.setOnClickListener(v -> {
            clearAvatarSelection(avatarViews);
            avatar3.setSelected(true);
            selectedAvatar[0] = "avatar_2";
        });

        avatar4.setOnClickListener(v -> {
            clearAvatarSelection(avatarViews);
            avatar4.setSelected(true);
            selectedAvatar[0] = "avatar_3";
        });

        AlertDialog dialog = builder.create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String description = etDescription.getText().toString().trim();
            if (description.isEmpty()) {
                description = "Belum ada deskripsi";
            }

            if (dbHelper.updateProfile(currentUser, selectedAvatar[0], description)) {
                Toast.makeText(getContext(), "Profil berhasil diperbarui!", Toast.LENGTH_SHORT).show();
                loadUserProfile(); // Refresh profile
                dialog.dismiss();
            } else {
                Toast.makeText(getContext(), "Gagal memperbarui profil!", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void clearAvatarSelection(ImageView[] avatarViews) {
        for (ImageView avatar : avatarViews) {
            avatar.setSelected(false);
        }
    }
}
