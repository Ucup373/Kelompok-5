package com.joshua.quizseratus;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.joshua.quizseratus.R;
import com.joshua.quizseratus.database.DatabaseHelper;
import com.joshua.quizseratus.ResultFragment;
import com.joshua.quizseratus.MainActivity;

import java.util.ArrayList;
import java.util.List;

public class QuizFragment extends Fragment {

    private TextView txtQuestion, txtProgress;
    private RadioGroup optionsGroup;
    private RadioButton optA, optB, optC, optD;
    private Button btnNext;
    private List<Question> questionList;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private String username;
    private String category;

    private DatabaseHelper dbHelper;

    public QuizFragment() {
        // Default constructor untuk Fragment
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);

        txtQuestion = view.findViewById(R.id.txtQuestion);
        txtProgress = view.findViewById(R.id.txtProgress);
        optionsGroup = view.findViewById(R.id.radioGroup);
        optA = view.findViewById(R.id.optionA);
        optB = view.findViewById(R.id.optionB);
        optC = view.findViewById(R.id.optionC);
        optD = view.findViewById(R.id.optionD);
        btnNext = view.findViewById(R.id.btnNext);

        dbHelper = new DatabaseHelper(getContext());

        // Ambil parameter dari Bundle
        Bundle args = getArguments();
        if (args != null) {
            category = args.getString("category");
            username = args.getString("username");
        }

        // Validasi parameter
        if (category == null || username == null) {
            Toast.makeText(getContext(), "Error: Parameter tidak valid", Toast.LENGTH_SHORT).show();
            return view;
        }

        // Ambil soal sesuai kategori dari database
        questionList = getQuestionsFromDatabase(category);

        // Validasi apakah ada soal
        if (questionList == null || questionList.isEmpty()) {
            Toast.makeText(getContext(), "Error: Tidak ada soal untuk kategori " + category, Toast.LENGTH_SHORT).show();
            return view;
        }

        showQuestion();

        btnNext.setOnClickListener(v -> {
            int selectedId = optionsGroup.getCheckedRadioButtonId();
            if (selectedId == -1) {
                Toast.makeText(getContext(), "Pilih jawaban dulu!", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton selected = view.findViewById(selectedId);
            String answer = selected.getText().toString();

            // Pastikan currentQuestionIndex masih dalam batas array
            if (currentQuestionIndex < questionList.size()) {
                String correctAnswer = questionList.get(currentQuestionIndex).getAnswer();

                if (answer.equals(correctAnswer)) {
                    score++;
                    Toast.makeText(getContext(), "Benar!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Salah! Jawaban benar: " + correctAnswer, Toast.LENGTH_SHORT).show();
                }
            }

            currentQuestionIndex++;

            if (currentQuestionIndex < questionList.size()) {
                showQuestion();
            } else {
                // Simpan skor ke database
                dbHelper.saveScore(username, category, score);

                // Navigasi ke ResultFragment
                Bundle resultBundle = new Bundle();
                resultBundle.putString("category", category);
                resultBundle.putString("username", username);
                resultBundle.putInt("score", score);
                resultBundle.putInt("total", questionList.size());

                ResultFragment resultFragment = new ResultFragment();
                resultFragment.setArguments(resultBundle);

                ((MainActivity) getActivity()).navigateTo(resultFragment);
            }
        });

        return view;
    }

    private void showQuestion() {
        Question q = questionList.get(currentQuestionIndex);
        txtQuestion.setText(q.getQuestion());
        optA.setText(q.getOptionA());
        optB.setText(q.getOptionB());
        optC.setText(q.getOptionC());
        optD.setText(q.getOptionD());
        optionsGroup.clearCheck();
        txtProgress.setText("Soal " + (currentQuestionIndex + 1) + " dari " + questionList.size());
    }

    private List<Question> getQuestionsFromDatabase(String category) {
        List<Question> list = new ArrayList<>();

        // Ambil soal dari database
        Cursor cursor = dbHelper.getQuestionsByCategory(category);

        if (cursor.moveToFirst()) {
            do {
                String question = cursor.getString(cursor.getColumnIndexOrThrow("question"));
                String optionA = cursor.getString(cursor.getColumnIndexOrThrow("option_a"));
                String optionB = cursor.getString(cursor.getColumnIndexOrThrow("option_b"));
                String optionC = cursor.getString(cursor.getColumnIndexOrThrow("option_c"));
                String optionD = cursor.getString(cursor.getColumnIndexOrThrow("option_d"));
                String answer = cursor.getString(cursor.getColumnIndexOrThrow("answer"));

                list.add(new Question(question, optionA, optionB, optionC, optionD, answer));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    // Model kelas untuk pertanyaan
    public static class Question {
        private final String question, optionA, optionB, optionC, optionD, answer;

        public Question(String question, String optionA, String optionB, String optionC, String optionD, String answer) {
            this.question = question;
            this.optionA = optionA;
            this.optionB = optionB;
            this.optionC = optionC;
            this.optionD = optionD;
            this.answer = answer;
        }

        public String getQuestion() { return question; }
        public String getOptionA() { return optionA; }
        public String getOptionB() { return optionB; }
        public String getOptionC() { return optionC; }
        public String getOptionD() { return optionD; }
        public String getAnswer() { return answer; }
    }
}
