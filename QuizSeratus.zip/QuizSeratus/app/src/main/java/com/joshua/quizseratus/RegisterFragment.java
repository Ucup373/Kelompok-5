package com.joshua.quizseratus;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterFragment extends Fragment {

    private EditText etUsername, etPassword, etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;

    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        etUsername = view.findViewById(R.id.etUsername);          // USERNAME biasa, misal: cupcup
        etPassword = view.findViewById(R.id.etPassword);
        etConfirmPassword = view.findViewById(R.id.etConfirmPassword);
        btnRegister = view.findViewById(R.id.btnRegister);
        tvLogin = view.findViewById(R.id.tvLogin);

        mAuth = FirebaseAuth.getInstance();

        btnRegister.setOnClickListener(v -> registerUser());

        // Tombol Login
        tvLogin.setOnClickListener(v -> {
            ((MainActivity) getActivity()).navigateTo(new LoginFragment());
        });

        return view;
    }

    private void registerUser() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            Toast.makeText(getContext(), "Isi semua kolom!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Boleh tambahkan validasi username (tanpa spasi, dll) kalau mau
        if (username.contains(" ")) {
            Toast.makeText(getContext(), "Username tidak boleh ada spasi!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(getContext(), "Password tidak sama!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(getContext(), "Password minimal 6 karakter!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buat "email palsu" dari username untuk Firebase
        String fakeEmail = username + "@quizseratus.app";

        mAuth.createUserWithEmailAndPassword(fakeEmail, password)
                .addOnCompleteListener(requireActivity(), new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            // Simpan info username di Realtime Database (opsional tapi bagus)
                            String uid = mAuth.getCurrentUser().getUid();
                            FirebaseDatabase.getInstance().getReference("users")
                                    .child(uid)
                                    .child("username")
                                    .setValue(username);

                            Toast.makeText(getContext(), "Registrasi berhasil!", Toast.LENGTH_SHORT).show();

                            // Pindah ke halaman login
                            ((MainActivity) getActivity()).navigateTo(new LoginFragment());
                        } else {
                            String msg = (task.getException() != null)
                                    ? task.getException().getMessage()
                                    : "Terjadi kesalahan";
                            Toast.makeText(getContext(), "Registrasi gagal: " + msg, Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }
}
