package com.joshua.quizseratus;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ResultFragment extends Fragment {

    private TextView txtCategory, txtScore, txtMessage, txtPercentage;
    private ProgressBar progressBar;
    private Button btnBackToHome, btnViewProfile;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_result, container, false);

        txtCategory = view.findViewById(R.id.txtCategory);
        txtScore = view.findViewById(R.id.txtScore);
        txtMessage = view.findViewById(R.id.txtMessage);
        txtPercentage = view.findViewById(R.id.txtPercentage);
        progressBar = view.findViewById(R.id.progressBar);
        btnBackToHome = view.findViewById(R.id.btnBackToHome);
        btnViewProfile = view.findViewById(R.id.btnViewProfile);

        Bundle bundle = getArguments();
        if (bundle != null) {
            String category = bundle.getString("category");
            int score = bundle.getInt("score");
            int total = bundle.getInt("total");

            // Validasi parameter
            if (category == null || total <= 0) {
                Toast.makeText(getContext(), "Error: Data hasil tidak valid", Toast.LENGTH_SHORT).show();
                return view;
            }

            // Tampilkan hasil
            txtCategory.setText("Kategori: " + category);
            txtScore.setText(score + " / " + total + " benar");

            // Hitung dan tampilkan persentase
            double percentage = (double) score / total * 100;
            int percentageInt = (int) Math.round(percentage);
            txtPercentage.setText(percentageInt + "%");

            // Update progress bar
            progressBar.setProgress(percentageInt);

            // Tentukan pesan berdasarkan skor dengan humor
            String message;
            if (percentage >= 90) {
                message = "WOW! Nilai A+!\nKamu kayaknya udah siap jadi dosen nih! \nMantap banget, terus pertahankan!";
            } else if (percentage >= 80) {
                message = "Excellent! Nilai A!\nKamu udah mahir banget nih!\nKayaknya bisa ngajarin temen-temen deh!";
            } else if (percentage >= 70) {
                message = "Bagus! Nilai B+\nLumayan nih, tapi masih bisa ditingkatkan!\nKayaknya perlu ngopi sambil belajar lagi!";
            } else if (percentage >= 60) {
                message = "Oke! Nilai B\nMasih dalam batas wajar sih...\nTapi jangan santai dulu, masih ada ruang untuk berkembang!";
            } else if (percentage >= 50) {
                message = "Hmm... Nilai C+\nKayaknya tadi sambil nonton YouTube ya? \nCoba lagi deh, kali ini fokus!";
            } else if (percentage >= 40) {
                message = "Nilai C\nWah, kayaknya perlu belajar lebih giat nih!\nJangan sampai kena remedial ya!";
            } else {
                message = "Nilai D\nWaduh... kayaknya perlu ngulang dari awal nih!\nTapi jangan menyerah, masih ada kesempatan!";
            }
            txtMessage.setText(message);

            // Simpan skor ke Firebase
            saveScoreToFirebase(category, score);

        } else {
            Toast.makeText(getContext(), "Error: Tidak ada data hasil", Toast.LENGTH_SHORT).show();
        }

        // Tombol kembali ke home
        btnBackToHome.setOnClickListener(v -> {
            ((MainActivity) getActivity()).navigateTo(new HomeFragment());
        });

        // Tombol lihat profil
        btnViewProfile.setOnClickListener(v -> {
            ((MainActivity) getActivity()).navigateTo(new ProfileFragment());
        });

        return view;
    }

    private void saveScoreToFirebase(String category, int score) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            Toast.makeText(getContext(), "Harus login untuk menyimpan skor", Toast.LENGTH_SHORT).show();
            return;
        }

        String uid = user.getUid();

        DatabaseReference scoresRef = FirebaseDatabase.getInstance()
                .getReference("scores")
                .child(uid);

        // Buat object skor
        Score scoreObj = new Score(category, score, System.currentTimeMillis());

        // Simpan dengan push (id unik)
        scoresRef.push().setValue(scoreObj)
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(getContext(), "Skor telah disimpan!", Toast.LENGTH_SHORT).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Gagal menyimpan skor: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }
}
