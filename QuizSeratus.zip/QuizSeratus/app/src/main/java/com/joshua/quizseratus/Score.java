package com.joshua.quizseratus;

public class Score {
    public String category;
    public int score;
    public long timestamp;

    public Score() {
        // Diperlukan oleh Firebase (constructor kosong)
    }

    public Score(String category, int score, long timestamp) {
        this.category = category;
        this.score = score;
        this.timestamp = timestamp;
    }
}
